# PrintApp Mobile – Testversion 0.1

Android-Testprojekt für vorlagenbasierten Etikettendruck. Die Startseite zeigt eine Ø35-mm-Vorlage mit editierbaren Feldern. Der Vorlageneditor kann SVG-Hintergründe importieren und variable Textfelder per Drag & Drop positionieren.

## Vorlagenformat
Eine `.printtemplate`-Datei ist ein ZIP-Container und enthält **immer** `template.json` und `background.svg`. Damit ist die SVG vollständig in die exportierte Vorlage integriert.

## Build lokal
`./gradlew assembleDebug`

## GitHub
Im Repository liegen `printapp-mobile.zip` und `.github/workflows/build-printapp-mobile.yml`. Die Action entpackt die ZIP, führt `./gradlew assembleDebug` aus und lädt die APK als Artifact hoch.

## Teststand
M110-BLE-Druck ist im Menü bereits vorgesehen, aber in dieser ersten UI-/Template-Testversion noch nicht aktiviert.
