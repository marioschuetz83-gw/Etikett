package de.printapp.mobile

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.webkit.WebView
import android.widget.*
import org.json.*
import java.util.zip.*
import java.io.*

class MainActivity : Activity() {
    private lateinit var template: Template
    private lateinit var root: LinearLayout
    private val REQ_IMPORT = 10
    private val REQ_EXPORT = 11
    private val REQ_SVG = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        template = Template.default(readAsset("sicherheitsbeleuchtung.svg"))
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun titleBar(title: String, menu: Boolean = true): LinearLayout {
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(16),dp(8),dp(8),dp(8)); setBackgroundColor(Color.WHITE) }
        val t=TextView(this).apply { text=title; textSize=22f; setTextColor(Color.BLACK); setTypeface(typeface,1) }
        bar.addView(t,LinearLayout.LayoutParams(0,dp(56),1f))
        if(menu){
            val b=Button(this).apply { text="⋮"; textSize=25f; setOnClickListener { showMenu(this) } }
            bar.addView(b,LinearLayout.LayoutParams(dp(56),dp(56)))
        }
        return bar
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this,anchor).apply {
            menu.add("Vorlagen bearbeiten"); menu.add("Drucker koppeln"); menu.add("Vorlage importieren"); menu.add("Vorlage exportieren")
            setOnMenuItemClickListener {
                when(it.title.toString()){
                    "Vorlagen bearbeiten" -> showEditor()
                    "Drucker koppeln" -> Toast.makeText(this@MainActivity,"BLE-Kopplung folgt in der nächsten Version.",Toast.LENGTH_LONG).show()
                    "Vorlage importieren" -> importTemplate()
                    "Vorlage exportieren" -> exportTemplate()
                }; true
            }; show()
        }
    }

    private fun showHome(){
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,247,247)) }
        root.addView(titleBar("PrintApp"))
        val label=TextView(this).apply { text="Vorlage"; textSize=14f; setPadding(dp(16),dp(12),0,dp(4)) }
        root.addView(label)
        val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf(template.name)); root.addView(spinner,LinearLayout.LayoutParams(-1,dp(52)))
        val card=FrameLayout(this).apply { setPadding(dp(16),dp(16),dp(16),dp(16)) }
        val labelView=makeLabel(false); card.addView(labelView,FrameLayout.LayoutParams(-1,dp(360)))
        root.addView(card,LinearLayout.LayoutParams(-1,0,1f))
        val print=Button(this).apply { text="DRUCKEN"; textSize=18f; isAllCaps=false; setOnClickListener { Toast.makeText(this@MainActivity,"Testversion: Druckausgabe wird als Nächstes mit dem M110 verbunden.",Toast.LENGTH_LONG).show() } }
        root.addView(print,LinearLayout.LayoutParams(-1,dp(64)).apply { setMargins(dp(16),dp(8),dp(16),dp(16)) })
        setContentView(root)
    }

    private fun makeLabel(editor:Boolean): FrameLayout {
        val frame=FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        val web=WebView(this).apply { setBackgroundColor(Color.TRANSPARENT); settings.javaScriptEnabled=false; loadDataWithBaseURL(null,template.svg,"image/svg+xml","UTF-8",null) }
        frame.addView(web,FrameLayout.LayoutParams(-1,-1))
        template.fields.forEach { f ->
            val e=EditText(this).apply {
                hint=f.name; textSize=f.fontSize; setTextColor(Color.BLACK); setHintTextColor(Color.GRAY); setSingleLine(false); setBackgroundColor(if(editor) 0x33D32F2F else 0x22FFFFFF)
                if(editor){ setOnTouchListener(DragTouch(this,f,frame)) }
            }
            e.tag=f
            frame.addView(e,fieldLayout(f))
        }
        return frame
    }

    private fun fieldLayout(f: Field): FrameLayout.LayoutParams {
        val size=dp(330); val scale=size/35f
        return FrameLayout.LayoutParams((f.w*scale).toInt(),(f.h*scale).toInt()).apply { leftMargin=dp(15)+(f.x*scale).toInt(); topMargin=dp(15)+(f.y*scale).toInt() }
    }

    private fun showEditor(){
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,247,247)) }
        val bar=titleBar("Vorlage bearbeiten",false)
        val back=Button(this).apply { text="←"; setOnClickListener { showHome() } }; bar.addView(back,0,LinearLayout.LayoutParams(dp(56),dp(56)))
        layout.addView(bar)
        val tools=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        val svgBtn=Button(this).apply { text="SVG importieren"; setOnClickListener { importSvg() } }
        val add=Button(this).apply { text="+ Textfeld"; setOnClickListener { template.fields.add(Field("field${template.fields.size+1}","Neues Feld",5f,10f,12f,6f,12f)); showEditor() } }
        tools.addView(svgBtn,LinearLayout.LayoutParams(0,dp(52),1f)); tools.addView(add,LinearLayout.LayoutParams(0,dp(52),1f)); layout.addView(tools)
        val hint=TextView(this).apply { text="Textfelder gedrückt halten und verschieben. Positionen werden in mm gespeichert."; setPadding(dp(16),dp(8),dp(16),dp(8)) }; layout.addView(hint)
        val holder=FrameLayout(this).apply { setPadding(dp(15),dp(15),dp(15),dp(15)) }; holder.addView(makeLabel(true),FrameLayout.LayoutParams(-1,dp(360))); layout.addView(holder,LinearLayout.LayoutParams(-1,0,1f))
        val io=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val imp=Button(this).apply { text="Import"; setOnClickListener { importTemplate() } }; val exp=Button(this).apply { text="Export"; setOnClickListener { exportTemplate() } }
        io.addView(imp,LinearLayout.LayoutParams(0,dp(58),1f)); io.addView(exp,LinearLayout.LayoutParams(0,dp(58),1f)); layout.addView(io)
        setContentView(layout)
    }

    inner class DragTouch(val view:View,val field:Field,val parent:FrameLayout): View.OnTouchListener {
        var dx=0f; var dy=0f
        override fun onTouch(v:View,e:android.view.MotionEvent):Boolean{
            when(e.action){
                0->{ dx=v.x-e.rawX; dy=v.y-e.rawY; return true }
                2->{ v.x=(e.rawX+dx).coerceIn(0f,(parent.width-v.width).toFloat()); v.y=(e.rawY+dy).coerceIn(0f,(parent.height-v.height).toFloat()); return true }
                1->{ val scale=dp(330)/35f; field.x=((v.x-dp(15))/scale).coerceIn(0f,35f); field.y=((v.y-dp(15))/scale).coerceIn(0f,35f); return true }
            }; return false
        }
    }

    private fun importSvg(){ startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="image/svg+xml" },REQ_SVG) }
    private fun importTemplate(){ startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/zip" },REQ_IMPORT) }
    private fun exportTemplate(){ startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/zip"; putExtra(Intent.EXTRA_TITLE,"${template.name.replace(" ","-").lowercase()}.printtemplate") },REQ_EXPORT) }

    override fun onActivityResult(req:Int,res:Int,data:Intent?){ super.onActivityResult(req,res,data); if(res!=RESULT_OK || data?.data==null)return; val uri=data.data!!
        try { when(req){
            REQ_SVG -> { template.svg=contentResolver.openInputStream(uri)!!.bufferedReader().readText(); showEditor() }
            REQ_EXPORT -> writeTemplate(uri)
            REQ_IMPORT -> { readTemplate(uri); showHome() }
        }} catch(e:Exception){ Toast.makeText(this,"Fehler: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun writeTemplate(uri:Uri){
        contentResolver.openOutputStream(uri)!!.use { out -> ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("template.json")); z.write(template.toJson().toString(2).toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("background.svg")); z.write(template.svg.toByteArray()); z.closeEntry()
        }}; Toast.makeText(this,"Vorlage inkl. SVG exportiert.",Toast.LENGTH_SHORT).show()
    }
    private fun readTemplate(uri:Uri){
        var json=""; var svg=""; ZipInputStream(contentResolver.openInputStream(uri)).use { z -> var e=z.nextEntry; while(e!=null){ val b=z.readBytes(); if(e.name=="template.json")json=String(b); if(e.name=="background.svg")svg=String(b); e=z.nextEntry } }
        template=Template.fromJson(JSONObject(json),svg)
    }
    private fun readAsset(name:String)=assets.open(name).bufferedReader().readText()

    data class Field(val id:String,var name:String,var x:Float,var y:Float,var w:Float,var h:Float,var fontSize:Float){
        fun json()=JSONObject().put("id",id).put("name",name).put("xMm",x).put("yMm",y).put("widthMm",w).put("heightMm",h).put("fontSizeSp",fontSize)
    }
    data class Template(var name:String,var svg:String,val fields:MutableList<Field>){
        fun toJson():JSONObject { val a=JSONArray(); fields.forEach{a.put(it.json())}; return JSONObject().put("formatVersion",1).put("name",name).put("widthMm",35).put("heightMm",35).put("background","background.svg").put("fields",a) }
        companion object {
            fun default(svg:String)=Template("Sicherheitsbeleuchtung Ø35 mm",svg, mutableListOf(
                Field("verteiler","Verteiler",3f,6f,29f,5f,11f), Field("stromkreis","Stromkreis",3f,21f,13f,8f,11f), Field("leuchte","Leuchte",19f,21f,13f,8f,11f)))
            fun fromJson(o:JSONObject,svg:String):Template { val fs=mutableListOf<Field>(); val a=o.getJSONArray("fields"); for(i in 0 until a.length()){ val f=a.getJSONObject(i); fs.add(Field(f.getString("id"),f.getString("name"),f.getDouble("xMm").toFloat(),f.getDouble("yMm").toFloat(),f.getDouble("widthMm").toFloat(),f.getDouble("heightMm").toFloat(),f.optDouble("fontSizeSp",12.0).toFloat())) }; return Template(o.getString("name"),svg,fs) }
        }
    }
}
