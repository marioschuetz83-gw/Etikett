plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "de.printapp.mobile"
    compileSdk = 36
    defaultConfig {
        applicationId = "de.printapp.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1-test"
    }
}
